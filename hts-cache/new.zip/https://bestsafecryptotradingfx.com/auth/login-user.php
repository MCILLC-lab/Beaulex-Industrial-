<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title> Login Form | Bestsafecryptotradingfx.com </title>
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>

    <link rel="stylesheet" href="new.css">
</head>
<body>
    <div class="content">
        <div class="row">
            <div class="col-md-4 offset-md-4 form login-form">
                <form action="login-user.php" method="POST" autocomplete="">
                    <h2 class="text-center">Login</h2>

                                        <div class="field">

                        <input class="form-control" type="email" name="email" placeholder="Email Address" required value="">
                         <span class="fas fa-user"></span>
                    </div>
                    <br>
                    <div class="field">

                        <input class="form-control" type="password" name="password" placeholder="Password" required>
                         <span class="fas fa-lock"></span>
                    </div>
                     <div class="forgot-pass">
          <a href="forgot-password.php">Forgot Password?</a></div>
          <button name="login">Sign in</button>
          <div class="sign-up">Not a member?
           <a href="signup-user.php">signup now</a>
                </form>
            </div>
        </div>
    </div>
    
</body>
</html>