<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Somehow I got an error, so I comment the title, just uncomment to show -->
     <title>Signup Form</title>
     <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
    <link rel="stylesheet" href="new.css">
</head>
<body>
    <div class="content">
        <div class="row">
            <div class="col-md-4 offset-md-4 form login-form">
                <form action="signup-user.php" method="POST" autocomplete="">
                    <h2 class="text-center">Signup Form</h2>
                    <p class="text-center">It's quick and easy.</p>
                                        <div class="field">
                        <input class="form-control" type="text" name="name" placeholder="Full Name" required value="">
                         <span class="fas fa-user"></span>
                    </div><br>
                    <div class="field">
                        <input class="form-control" type="email" name="email" placeholder="Email Address" required value="">
                         <span class="fas fa-envelope"></span>
                    </div><br>
                     <div class="field">
                        <input class="form-control" type="text" name="country" placeholder="Country" required value="">
                         <span class="fas fa-flag"></span>
                    </div><br>
                    <div class="field">
                        <input class="form-control" type="password" name="password" placeholder="Password" required>
                         <span class="fas fa-lock"></span>
                    </div><br>
                    <div class="field"><br>
                        <input class="form-control" type="password" name="cpassword" placeholder="Confirm password" required>
                         <span class="fas fa-lock"></span>
                    </div>
                    <div class="field">
                        <button name="signup">Signup</button<br>
                    </div><br><br>
                    <div class="link login-link text-center">Already a member? 
                      <a href="login-user.php">Login here</a> <br>
                  </div>
                </form>
            </div>
        </div>
    </div>
</body>
</html>
