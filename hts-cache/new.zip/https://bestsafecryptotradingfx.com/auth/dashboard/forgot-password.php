<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Forgot Password</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="new.css">
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
</head>
<body>
    <div class="content">
        <div class="row">
            <div class="col-md-4 offset-md-4 form login-form">
                <form action="forgot-password.php" method="POST" autocomplete="">
                    <h2 class="text-center">Forgot Password</h2>
                    <p class="text-center">Enter your email address</p>
                                        <div class="field">
                        <input class="form-control" type="email" name="email" placeholder="Enter email address" required value="">
                        <span class="fas fa-envelope"></span>
                    </div>
                    <div class="field">
                   <button name="check-email">Send Email</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
</body>
</html>